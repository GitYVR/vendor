Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Public Enum EValidatorState
	IDLE
	BUSY
End Enum
