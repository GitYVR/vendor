Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Public Class [Global]
	Public Shared ComPort As String = ""
	Public Shared SSPAddress As Byte = 0
End Class
