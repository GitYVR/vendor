#ifndef _RANDOM_H
#define _RANDOM_H

#include "stdafx.h"

#define MAX_RANDOM_INTEGER		2147483648U //Should make these numbers massive to be more secure
#define MAX_PRIME_NUMBER		2147483648U //Bigger the number the slower the algorithm
								
/*		Linear Feedback Shift Registers			*/
#define LFSR(n)    {if (n&1) n=((n^0x80000055)>>1)|0x80000000; else n>>=1;}
/*		Rotate32								*/
#define ROT(x, y)  (x=(x<<y)|(x>>(32-y)))

typedef unsigned __int64 uint64;
typedef signed   __int64 int64;

uint64 GeneratePrime(void);
bool IsItPrime (int64 n, int64 a);
uint64 XpowYmodN(uint64 x, uint64 y, uint64 N);
uint64 GenerateRandomNumber(void);
int64 GetRTSC( void );



#endif

