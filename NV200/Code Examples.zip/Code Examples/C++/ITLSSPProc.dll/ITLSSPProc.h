#ifndef ITLSSPPROC_H_INCLUDED
#define ITLSSPPROC_H_INCLUDED

#define CCONV _stdcall
#define NOMANGLE

#include "sspcoms.h"

#define MAX_SSP_PORT 200


typedef signed char INT8;
typedef unsigned char UINT8;
typedef volatile signed char VINT8;
typedef volatile unsigned char VUINT8;

typedef signed short INT16;
typedef unsigned short UINT16;
typedef volatile signed short VINT16;
typedef volatile unsigned short VUINT16;

//typedef signed long INT32;
//typedef unsigned long UINT32;
typedef volatile signed long VINT32;
typedef volatile unsigned long VUINT32;

typedef signed long long INT64;
typedef unsigned long long UINT64;
typedef volatile signed long long VINT64;
typedef volatile unsigned long long VUINT64;

typedef enum{ 
    LEVEL_CHECK_OFF = 254,
    LEVEL_CHECK_ON
}LEVEL_CHECK;


typedef enum{
  FLOAT_PAYOUT_TO_PAYOUT,
  FLOAT_PAYOUT_TO_CASHBOX,	
}FLOAT_MODE;

typedef enum{
	LEVEL_NOT_SUFFICIENT = 1,
	NOT_EXACT_AMOUNT,
	HOPPER_BUSY,
	HOPPER_DISABLED,
	REQ_STATUS_OK = 255
}PAYOUT_REQ_STATUS;


typedef enum{
	DEAL_MODE_SPLIT = 0xFE,
	DEAL_MODE_FREE,
}DEAL_MODE;

typedef struct{
	UINT16 CoinValue;
	UINT32 CoinLevel;
	UINT8 CountryCode[3];
}COINS;

#define MAX_COIN_CHANNEL		30

typedef struct{
	UINT8 NumberOfCoinValues;
	COINS CoinsToPay[MAX_COIN_CHANNEL];
	COINS CoinsInHopper[MAX_COIN_CHANNEL];
	UINT8 FloatMode[MAX_COIN_CHANNEL];
	UINT8 DealTest[MAX_COIN_CHANNEL];
	UINT16 SearchTime[MAX_COIN_CHANNEL];
	UINT16 SplitQty[MAX_COIN_CHANNEL];
	UINT32 AmountPayOutRequest;
	UINT32* AmountPaidOut;
	UINT32 FloatAmountRequest;
	UINT32* MinPayout;
	UINT32* valueInHopper;
	UINT32* CashboxAmount;
	UINT32* TotalAvailableValue;
	UINT32 GlobalSearchTime;
	UINT8  CountryCode[3];
	UINT8  NewCoinCredit;
	UINT32 AmountToPay;
	UINT8 Mode;
	UINT8 DealMode;
	UINT8 LevelMode;
	UINT8 ExitMode;
	UINT16 MinPayoutRequest;
	UINT8 PayoutCountryReq[3];
	UINT8 ProtocolVersion;
	UINT8 CurrentCountryIndex;
	UINT8  NumCountries;
	UINT8* MultiCountryCodes;
}PAY;


typedef struct
{
	BYTE param1;
	BYTE param2;
	BYTE param3;
	unsigned short param4;
	unsigned short n;
	BYTE buffer[256];
	BYTE secArray[6];

}cctUDT;



int CreateHostInterKey(__int64* keyArray);
int CreateSlaveInterKey(__int64* keyArray);
int CreateSlaveEncryptionKey(__int64* keyArray);

#ifdef __cplusplus
extern "C" {
#endif

NOMANGLE int CCONV TestSSPSlaveKeys(__int64*  keyArray);
NOMANGLE int CCONV CreateSSPHostEncryptionKey(__int64* keyArray);
int EncryptSSPPacket(unsigned char ptNum,unsigned char* dataIn, unsigned char* dataOut, unsigned char* lengthIn,unsigned char* lengthOut, unsigned __int64* key);
int EncryptSSPMultiplePortPacket(unsigned char portIndex, unsigned char address,unsigned char* dataIn, unsigned char* dataOut, unsigned char* lengthIn,unsigned char* lengthOut, unsigned __int64* key);
int DecryptSSPPacket(unsigned char* dataIn, unsigned char* dataOut, unsigned char* lengthIn,unsigned char* lengthOut, unsigned __int64* key);
NOMANGLE int CCONV GetProcDLLVersion(unsigned char* ver);
NOMANGLE int CCONV InitiateSSPHostKeys(__int64*  keyArray,SSP_COMMAND* cmd);
NOMANGLE int CCONV TestSplit(PAY* py,UINT32 valueToFind);

#ifdef __cplusplus
}
#endif
#endif
