#define CCONV _stdcall
#define NOMANGLE

/*----------------------------------------------------------------------------------------------
---------------------------- Header includes ---------------------------------------------------
------------------------------------------------------------------------------------------------*/				
#include "stdafx.h"
#include <stdlib.h>
#include "SSPComs.h"
#include "ITLSSPProc.h"
#include "Encryption.h"
#include <windows.h>
#include <winbase.h>         // standard windows defines
#include <process.h>         // for multithreading functions
#include <winver.h>			 // for version information
#include <time.h>               /* for clock() and clock_t */
#include <fstream>
#include <iostream>
#include <io.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>


int pktTestCount = 1;


extern unsigned int encPktCount[MAX_SSP_PORT];
unsigned char MIN_DELAY_TIME = 1;

/*-------------------------------------------------------------------
------------------- module function prototypes-----------------------
---------------------------------------------------------------------*/
void EventNotify(PVOID);
void EventNotify2(PVOID);
void EventNotifyUSB(PVOID);
void EventNotifyMultiple0(PVOID);
void EventNotifyMultiple1(PVOID);
void EventNotifyMultiple2(PVOID);
void EventNotifyMultiple3(PVOID);
void EventNotifyMultiple4(PVOID);
void EventNotifyMultiple5(PVOID);
void EventNotifyMultiple6(PVOID);
void EventNotifyMultiple7(PVOID);
void EventNotifyMultiple8(PVOID);
void EventNotifyMultiple9(PVOID);
void EventNotifyMultiple10(PVOID);
void EventNotifyMultiple11(PVOID);
void EventNotifyMultiple12(PVOID);
void EventNotifyMultiple13(PVOID);
void EventNotifyMultiple14(PVOID);
void EventNotifyMultiple15(PVOID);
void EventNotifyMultiple16(PVOID);
void EventNotifyMultiple17(PVOID);
void EventNotifyMultiple18(PVOID);
void EventNotifyMultiple19(PVOID);
/* function pointer the threads  */
void (*evThread[20])(PVOID) = {EventNotifyMultiple0,EventNotifyMultiple1,EventNotifyMultiple2,EventNotifyMultiple3,EventNotifyMultiple4,EventNotifyMultiple5,
							   EventNotifyMultiple6,EventNotifyMultiple7,EventNotifyMultiple8,EventNotifyMultiple9,EventNotifyMultiple10,EventNotifyMultiple11,
							   EventNotifyMultiple12,EventNotifyMultiple13,EventNotifyMultiple14,EventNotifyMultiple15,EventNotifyMultiple16,EventNotifyMultiple17,
							   EventNotifyMultiple18,EventNotifyMultiple19};

void SetOS(void);
int CompileSSPCommand(SSP_COMMAND* cmd,SSP_TX_RX_PACKET* ss,SSP_COMMAND_INFO* sspInfo);
int CompileSSPMultiplePortCommand(SSP_COMMAND* cmd,SSP_TX_RX_PACKET* ss,SSP_COMMAND_INFO* sspInfo,unsigned char portIndex);
BOOL WritePort(SSP_TX_RX_PACKET* ss);
BOOL WritePort2(SSP_TX_RX_PACKET* ss);
BOOL WritePortUSB(SSP_TX_RX_PACKET* ss);
BOOL WritePortMultiple(SSP_TX_RX_PACKET* ss, unsigned char portIndex);
unsigned char ReadPort(void);
unsigned char ReadPort2(void);
unsigned char ReadPortUSB(void);
unsigned char ReadPortMultiple(unsigned char portIndex);
void SSPDataIn(unsigned char RxChar, SSP_TX_RX_PACKET* ss);
void DownloadITLTarget(void* data);
int CloseSystemPort(unsigned char portIndex);
int OpenSystemPort(PORT_CONFIG* pt, unsigned char portIndex);
/*--------------------------------------------------------------------
------------------- module variables ---------------------------------
----------------------------------------------------------------------*/
int PortStatus = PORT_CLOSED;
int PortStatus2 = PORT_CLOSED;
int PortStatusUSB = PORT_CLOSED;
typedef enum {W_32s,W_95,W_NT} OS_VER; // for os versions
OS_VER OS;
HANDLE hDevice;					// handle to com device
HANDLE hDevice2;
HANDLE hDeviceUSB;
bool bActive = FALSE;
bool bActive2 = FALSE;
bool bActiveUSB = FALSE;
unsigned char ulCharsGone = 0;
//unsigned char sspSeq = 0x80;
unsigned char sspSeq[MAX_SSP_PORT];
OVERLAPPED oNotify;            // overlapped structure for non-blocking threads
SSP_TX_RX_PACKET ssp;	
SSP_TX_RX_PACKET ssp2;
SSP_TX_RX_PACKET sspUSB;
ITL_FILE_DOWNLOAD itlFile;
RAM_UPDATE_STATUS ramStatus;
SSP_COMMAND sspC;
SSP_COMMAND_INFO sspCmdInfo;
short ChkSumRx = -1;
BOOL RxVerify = false;
unsigned char RAM_STARTUP_TIME = 18;
SYSTEM_PORTS systemPorts;

HINSTANCE hinstLib;



/*--------------------------------------------------------------------------
------------------- module functions ----------------------------------------
-----------------------------------------------------------------------------*/

NOMANGLE int CCONV SSPSendCommand(SSP_COMMAND* cmd, SSP_COMMAND_INFO* sspInfo)
{
	
	clock_t txTime,currentTime,rxTime;
	int i;
	unsigned char encryptLength;
	unsigned short crcR;
	unsigned char tData[255];
	unsigned char retry, portIndex;
	unsigned int slaveCount;
	char tmp1;
	
	/* do we have multi port active ?*/
	if(systemPorts.NumberOfPorts){ 
		portIndex = 255;
		/* find which poer index is for this cmd  */
		for(i = 0; i < MAX_PORT_ID; i++){
			if(systemPorts.PortID[i] == cmd->PortNumber){
				portIndex = i;
				break;
			}
		}
		/* valid port found ? */
		if(portIndex == 255){
			cmd->ResponseStatus = PORT_ERROR;
			return 0;			
		}
		
		/* complie the SSP packet and check for errors  */	
		if(!CompileSSPMultiplePortCommand(cmd,&systemPorts.sspPkt[portIndex], sspInfo ,portIndex)){
			cmd->ResponseStatus = SSP_PACKET_ERROR;
			return 0;
		}

		retry = cmd->RetryLevel; 
					/* transmit the packet    */
		do{
			systemPorts.sspPkt[portIndex].NewResponse = 0;  /* set flag to wait for a new reply from slave   */
			if(WritePortMultiple(&systemPorts.sspPkt[portIndex],portIndex) != TRUE){
				cmd->ResponseStatus = PORT_ERROR;
				return 0;
			}
						
			/* wait for out reply   */
			cmd->ResponseStatus = SSP_REPLY_OK;
			txTime = clock();
			while(!systemPorts.sspPkt[portIndex].NewResponse){
				/* check for reply timeout   */
				currentTime = clock();
				if(currentTime - txTime > cmd->Timeout){
					PortStatus = SSP_CMD_TIMEOUT;
					cmd->ResponseStatus = SSP_CMD_TIMEOUT;
					break;
				}
			}									
			if(cmd->ResponseStatus == SSP_REPLY_OK)
					break;

				retry--;
		}while(retry > 0);		

		/* check for time out */
		rxTime = clock();
		sspInfo->Receive.packetTime = (unsigned short)(rxTime - txTime);
		if(cmd->ResponseStatus == SSP_CMD_TIMEOUT){
			sspInfo->Receive.PacketLength = 0;
			return 0;
		}
		/* copy data to info structure  */
		sspInfo->Receive.PacketLength = systemPorts.sspPkt[portIndex].rxData[2] + 5;
		for(i = 0; i < sspInfo->Receive.PacketLength; i++)
			sspInfo->Receive.PacketData[i] = systemPorts.sspPkt[portIndex].rxData[i];
		/* load the command structure with ssp packet data   */
		if(systemPorts.sspPkt[portIndex].rxData[3] == SSP_STEX){   /* check for encrpted packet    */

			encryptLength = systemPorts.sspPkt[portIndex].rxData[2] - 1;
			DecryptSSPPacket(&systemPorts.sspPkt[portIndex].rxData[4],&systemPorts.sspPkt[portIndex].rxData[4],&encryptLength,&encryptLength,(unsigned __int64*)&cmd->Key);	
			/* check the checsum    */
			crcR = cal_crc_loop_CCITT_A(encryptLength - 2,&systemPorts.sspPkt[portIndex].rxData[4] ,CRC_SSP_SEED,CRC_SSP_POLY);
			if((unsigned char)(crcR & 0xFF) != systemPorts.sspPkt[portIndex].rxData[systemPorts.sspPkt[portIndex].rxData[2] + 1] || (unsigned char)((crcR >> 8) & 0xFF) != systemPorts.sspPkt[portIndex].rxData[systemPorts.sspPkt[portIndex].rxData[2] + 2]){
				cmd->ResponseStatus = SSP_PACKET_ERROR;
				sspInfo->Receive.PacketLength = 0;
				return 0;				
			}
			/* check the slave count against the host count  */
			slaveCount = 0;
			for(i = 0; i < 4; i++)
				slaveCount += (unsigned int)(systemPorts.sspPkt[portIndex].rxData[5 + i]) << (i*8); 
			/* no match then we discard this packet and do not act on it's info  */
			if(slaveCount != systemPorts.sspPkt[portIndex].encPktCount[cmd->SSPAddress]){
				cmd->ResponseStatus = SSP_PACKET_ERROR;
				sspInfo->Receive.PacketLength = 0;
				return 0;
			}

			/* restore data for correct decode  */
			systemPorts.sspPkt[portIndex].rxBufferLength = systemPorts.sspPkt[portIndex].rxData[4] + 5;
			tData[0] = systemPorts.sspPkt[portIndex].rxData[0];
			tData[1] = systemPorts.sspPkt[portIndex].rxData[1];
			tData[2] = systemPorts.sspPkt[portIndex].rxData[4];
			for(i = 0; i < systemPorts.sspPkt[portIndex].rxData[4]; i++)
				tData[3 + i] = systemPorts.sspPkt[portIndex].rxData[9 + i];
			crcR = cal_crc_loop_CCITT_A(systemPorts.sspPkt[portIndex].rxBufferLength - 3,&tData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
			tData[3 + systemPorts.sspPkt[portIndex].rxData[4]] = (unsigned char)(crcR & 0xFF);
			tData[4 + systemPorts.sspPkt[portIndex].rxData[4]] = (unsigned char)((crcR >> 8) & 0xFF);
			for(i = 0; i < systemPorts.sspPkt[portIndex].rxBufferLength; i++)
				systemPorts.sspPkt[portIndex].rxData[i] = tData[i]; 
			
			/* for decrypted resonse with encrypted command, increment the counter here  */
		//	if(!cmd->EncryptionStatus)
			 // encPktCount[cmd->SSPAddress]++;


		}


		cmd->ResponseDataLength = systemPorts.sspPkt[portIndex].rxData[2];
		for(i = 0; i < cmd->ResponseDataLength; i++)
			cmd->ResponseData[i] = systemPorts.sspPkt[portIndex].rxData[i + 3];  


		sspInfo->PreEncryptedRecieve.PacketLength = systemPorts.sspPkt[portIndex].rxBufferLength;
		for(i = 0; i < systemPorts.sspPkt[portIndex].rxBufferLength; i++)
			sspInfo->PreEncryptedRecieve.PacketData[i] = systemPorts.sspPkt[portIndex].rxData[i];   

			
		/* alternate the seq bit   */
		if(systemPorts.sspPkt[portIndex].sspSeq[cmd->SSPAddress] == 0x80)
			systemPorts.sspPkt[portIndex].sspSeq[cmd->SSPAddress] = 0;
		else
			systemPorts.sspPkt[portIndex].sspSeq[cmd->SSPAddress] = 0x80;


	}else{
			/* for same com port ID's    */
			if(bActiveUSB){

					/* complie the SSP packet and check for errors  */	
					if(!CompileSSPCommand(cmd,&sspUSB, sspInfo )){
						cmd->ResponseStatus = SSP_PACKET_ERROR;
						return 0;
					}


					retry = cmd->RetryLevel; 
					/* transmit the packet    */
					do{
						sspUSB.NewResponse = 0;  /* set flag to wait for a new reply from slave   */
						if(WritePortUSB(&sspUSB) != TRUE){
							cmd->ResponseStatus = PORT_ERROR;
							return 0;
						}
						
						/* wait for out reply   */
						cmd->ResponseStatus = SSP_REPLY_OK;
						txTime = clock();
						while(!sspUSB.NewResponse){
							/* check for reply timeout   */
							currentTime = clock();
							if(currentTime - txTime > cmd->Timeout){
								PortStatus = SSP_CMD_TIMEOUT;
								cmd->ResponseStatus = SSP_CMD_TIMEOUT;
								break;
							}
						}
						
						
						if(cmd->ResponseStatus == SSP_REPLY_OK)
							break;

						retry--;
					}while(retry > 0);


					rxTime = clock();
					sspInfo->Receive.packetTime = (unsigned short)(rxTime - txTime);

					if(cmd->ResponseStatus == SSP_CMD_TIMEOUT){
							sspInfo->Receive.PacketLength = 0;
							return 0;
					}

					
					sspInfo->Receive.PacketLength = sspUSB.rxData[2] + 5;
					for(i = 0; i < sspInfo->Receive.PacketLength; i++)
						sspInfo->Receive.PacketData[i] = sspUSB.rxData[i];


					/* load the command structure with ssp packet data   */
					if(sspUSB.rxData[3] == SSP_STEX){   /* check for encrpted packet    */

						encryptLength = sspUSB.rxData[2] - 1;
						DecryptSSPPacket(&sspUSB.rxData[4],&sspUSB.rxData[4],&encryptLength,&encryptLength,(unsigned __int64*)&cmd->Key);	
						/* check the checsum    */
						crcR = cal_crc_loop_CCITT_A(encryptLength - 2,&sspUSB.rxData[4] ,CRC_SSP_SEED,CRC_SSP_POLY);
						if((unsigned char)(crcR & 0xFF) != sspUSB.rxData[sspUSB.rxData[2] + 1] || (unsigned char)((crcR >> 8) & 0xFF) != sspUSB.rxData[sspUSB.rxData[2] + 2]){
							cmd->ResponseStatus = SSP_PACKET_ERROR;
							sspInfo->Receive.PacketLength = 0;
							return 0;				
						}
						/* check the slave count against the host count  */
						slaveCount = 0;
						for(i = 0; i < 4; i++)
							slaveCount += (unsigned int)(sspUSB.rxData[5 + i]) << (i*8); 
						/* no match then we discard this packet and do not act on it's info  */
						if(slaveCount != encPktCount[cmd->SSPAddress] ){
							cmd->ResponseStatus = SSP_PACKET_ERROR;
							sspInfo->Receive.PacketLength = 0;
							return 0;
						}

						/* restore data for correct decode  */
						sspUSB.rxBufferLength = sspUSB.rxData[4] + 5;
						tData[0] = sspUSB.rxData[0];
						tData[1] = sspUSB.rxData[1];
						tData[2] = sspUSB.rxData[4];
						for(i = 0; i < sspUSB.rxData[4]; i++)
							tData[3 + i] = sspUSB.rxData[9 + i];
						crcR = cal_crc_loop_CCITT_A(sspUSB.rxBufferLength - 3,&tData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
						tData[3 + sspUSB.rxData[4]] = (unsigned char)(crcR & 0xFF);
						tData[4 + sspUSB.rxData[4]] = (unsigned char)((crcR >> 8) & 0xFF);
						for(i = 0; i < sspUSB.rxBufferLength; i++)
							sspUSB.rxData[i] = tData[i]; 
						
						/* for decrypted resonse with encrypted command, increment the counter here  */
					//	if(!cmd->EncryptionStatus)
						 // encPktCount[cmd->SSPAddress]++;


					}


					cmd->ResponseDataLength = sspUSB.rxData[2];
					for(i = 0; i < cmd->ResponseDataLength; i++)
						cmd->ResponseData[i] = sspUSB.rxData[i + 3];  


					sspInfo->PreEncryptedRecieve.PacketLength = sspUSB.rxBufferLength;
					for(i = 0; i < sspUSB.rxBufferLength; i++)
						sspInfo->PreEncryptedRecieve.PacketData[i] = sspUSB.rxData[i];   

						
					/* alternate the seq bit   */
					if(sspSeq[cmd->SSPAddress] == 0x80)
						sspSeq[cmd->SSPAddress] = 0;
					else
						sspSeq[cmd->SSPAddress] = 0x80;




			}else{

				if(cmd->SSPAddress == 0){
					/* complie the SSP packet and check for errors  */	
					if(!CompileSSPCommand(cmd,&ssp, sspInfo )){
						cmd->ResponseStatus = SSP_PACKET_ERROR;
						return 0;
					}

					retry = cmd->RetryLevel; 
					/* transmit the packet    */
					do{
						ssp.NewResponse = 0;  /* set flag to wait for a new reply from slave   */
						if(WritePort(&ssp) != TRUE){
							cmd->ResponseStatus = PORT_ERROR;
							return 0;
						}
						
						/* wait for out reply   */
						cmd->ResponseStatus = SSP_REPLY_OK;
						txTime = clock();
						while(!ssp.NewResponse){
							/* check for reply timeout   */
							currentTime = clock();
							if(currentTime - txTime > cmd->Timeout){
								PortStatus = SSP_CMD_TIMEOUT;
								cmd->ResponseStatus = SSP_CMD_TIMEOUT;
								break;
							}
						}
						
						if(cmd->ResponseStatus == SSP_REPLY_OK)
							break;

						retry--;
					}while(retry > 0);


					rxTime = clock();
					sspInfo->Receive.packetTime = (unsigned short)(rxTime - txTime);

					if(cmd->ResponseStatus == SSP_CMD_TIMEOUT){
							sspInfo->Receive.PacketLength = 0;
							return 0;
					}

					sspInfo->Receive.PacketLength = ssp.rxData[2] + 5;
					for(i = 0; i < sspInfo->Receive.PacketLength; i++)
						sspInfo->Receive.PacketData[i] = ssp.rxData[i];			

					/* load the command structure with ssp packet data   */
					if(ssp.rxData[3] == SSP_STEX){   /* check for encrpted packet    */
						encryptLength = ssp.rxData[2] - 1;
						DecryptSSPPacket(&ssp.rxData[4],&ssp.rxData[4],&encryptLength,&encryptLength,(unsigned __int64*)&cmd->Key);	
						/* check the checsum    */
						crcR = cal_crc_loop_CCITT_A(encryptLength - 2,&ssp.rxData[4] ,CRC_SSP_SEED,CRC_SSP_POLY);
						if((unsigned char)(crcR & 0xFF) != ssp.rxData[ssp.rxData[2] + 1] || (unsigned char)((crcR >> 8) & 0xFF) != ssp.rxData[ssp.rxData[2] + 2]){
							cmd->ResponseStatus = SSP_PACKET_ERROR;
							sspInfo->Receive.PacketLength = 0;
							return 0;				
						}
						/* check the slave count against the host count  */
						slaveCount = 0;
						for(i = 0; i < 4; i++)
							slaveCount += (unsigned int)(ssp.rxData[5 + i]) << (i*8); 
						/* no match then we discard this packet and do not act on it's info  */
						if(slaveCount != encPktCount[cmd->SSPAddress] ){
							cmd->ResponseStatus = SSP_PACKET_ERROR;
							sspInfo->Receive.PacketLength = 0;
							return 0;
						}

						/* restore data for correct decode  */
						ssp.rxBufferLength = ssp.rxData[4] + 5;
						tData[0] = ssp.rxData[0];
						tData[1] = ssp.rxData[1];
						tData[2] = ssp.rxData[4];
						for(i = 0; i < ssp.rxData[4]; i++)
							tData[3 + i] = ssp.rxData[9 + i];
						crcR = cal_crc_loop_CCITT_A(ssp.rxBufferLength - 3,&tData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
						tData[3 + ssp.rxData[4]] = (unsigned char)(crcR & 0xFF);
						tData[4 + ssp.rxData[4]] = (unsigned char)((crcR >> 8) & 0xFF);
						for(i = 0; i < ssp.rxBufferLength; i++)
							ssp.rxData[i] = tData[i]; 
						
						/* for decrypted resonse with encrypted command, increment the counter here  */
					//	if(!cmd->EncryptionStatus)
						 // encPktCount[cmd->SSPAddress]++;


					}


					cmd->ResponseDataLength = ssp.rxData[2];
					for(i = 0; i < cmd->ResponseDataLength; i++)
						cmd->ResponseData[i] = ssp.rxData[i + 3];  



					sspInfo->PreEncryptedRecieve.PacketLength = ssp.rxBufferLength;
					for(i = 0; i < ssp.rxBufferLength; i++)
						sspInfo->PreEncryptedRecieve.PacketData[i] = ssp.rxData[i];  

					/* alternate the seq bit   */
					if(sspSeq[cmd->SSPAddress] == 0x80)
						sspSeq[cmd->SSPAddress] = 0;
					else
						sspSeq[cmd->SSPAddress] = 0x80;

				}else{
					/* complie the SSP packet and check for errors  */	
					if(!CompileSSPCommand(cmd,&ssp2, sspInfo )){
						cmd->ResponseStatus = SSP_PACKET_ERROR;
						return 0;
					}

					retry = cmd->RetryLevel; 
					/* transmit the packet    */
					do{
						ssp2.NewResponse = 0;  /* set flag to wait for a new reply from slave   */
						if(WritePort2(&ssp2) != TRUE){
							cmd->ResponseStatus = PORT_ERROR;
							return 0;
						}
						
						/* wait for out reply   */
						cmd->ResponseStatus = SSP_REPLY_OK;
						txTime = clock();
						while(!ssp2.NewResponse){
							/* check for reply timeout   */
							currentTime = clock();
							if(currentTime - txTime > cmd->Timeout){
								PortStatus2 = SSP_CMD_TIMEOUT;
								cmd->ResponseStatus = SSP_CMD_TIMEOUT;
								break;
							}
						}
						
						if(cmd->ResponseStatus == SSP_REPLY_OK)
							break;

						retry--;
					}while(retry > 0);


					rxTime = clock();
					sspInfo->Receive.packetTime = (unsigned short)(rxTime - txTime);

					if(cmd->ResponseStatus == SSP_CMD_TIMEOUT){
							sspInfo->Receive.PacketLength = 0;
							return 0;
					}

					sspInfo->Receive.PacketLength = ssp2.rxData[2] + 5;
					for(i = 0; i < sspInfo->Receive.PacketLength; i++)
						sspInfo->Receive.PacketData[i] = ssp2.rxData[i];	
					

					/* load the command structure with ssp packet data   */
					if(ssp2.rxData[3] == SSP_STEX){   /* check for encrpted packet    */
						encryptLength = ssp2.rxData[2] - 1;
						DecryptSSPPacket(&ssp2.rxData[4],&ssp2.rxData[4],&encryptLength,&encryptLength,(unsigned __int64*)&cmd->Key);	
						/* check the checsum    */
						crcR = cal_crc_loop_CCITT_A(encryptLength - 2,&ssp2.rxData[4] ,CRC_SSP_SEED,CRC_SSP_POLY);
						if((unsigned char)(crcR & 0xFF) != ssp2.rxData[ssp2.rxData[2] + 1] || (unsigned char)((crcR >> 8) & 0xFF) != ssp2.rxData[ssp2.rxData[2] + 2]){
							cmd->ResponseStatus = SSP_PACKET_ERROR;
							sspInfo->Receive.PacketLength = 0;
							return 0;				
						}
						/* check the slave count against the host count  */
						slaveCount = 0;
						for(i = 0; i < 4; i++)
							slaveCount += (unsigned int)(ssp2.rxData[5 + i]) << (i*8); 
						/* no match then we discard this packet and do not act on it's info  */
						if(slaveCount != encPktCount[cmd->SSPAddress] ){
							cmd->ResponseStatus = SSP_PACKET_ERROR;
							sspInfo->Receive.PacketLength = 0;
							return 0;
						}

						/* restore data for correct decode  */
						ssp2.rxBufferLength = ssp2.rxData[4] + 5;
						tData[0] = ssp2.rxData[0];
						tData[1] = ssp2.rxData[1];
						tData[2] = ssp2.rxData[4];
						for(i = 0; i < ssp2.rxData[4]; i++)
							tData[3 + i] = ssp2.rxData[9 + i];
						crcR = cal_crc_loop_CCITT_A(ssp2.rxBufferLength - 3,&tData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
						tData[3 + ssp2.rxData[4]] = (unsigned char)(crcR & 0xFF);
						tData[4 + ssp2.rxData[4]] = (unsigned char)((crcR >> 8) & 0xFF);
						for(i = 0; i < ssp2.rxBufferLength; i++)
							ssp2.rxData[i] = tData[i]; 
						
						/* for decrypted resonse with encrypted command, increment the counter here  */
					//	if(!cmd->EncryptionStatus)
						  //encPktCount[cmd->SSPAddress]++;


					}


					cmd->ResponseDataLength = ssp2.rxData[2];
					for(i = 0; i < cmd->ResponseDataLength; i++)
						cmd->ResponseData[i] = ssp2.rxData[i + 3];  



					sspInfo->PreEncryptedRecieve.PacketLength = ssp2.rxBufferLength;
					for(i = 0; i < ssp2.rxBufferLength; i++)
						sspInfo->PreEncryptedRecieve.PacketData[i] = ssp2.rxData[i];  

					/* alternate the seq bit   */
					if(sspSeq[cmd->SSPAddress] == 0x80)
						sspSeq[cmd->SSPAddress] = 0;
					else
						sspSeq[cmd->SSPAddress] = 0x80;

				}
			}

		}
			/* terminate the thread function   */
		cmd->ResponseStatus = SSP_REPLY_OK;
	


	return 1;

}

int CompileSSPMultiplePortCommand(SSP_COMMAND* cmd,SSP_TX_RX_PACKET* ss,SSP_COMMAND_INFO* sspInfo, unsigned char portIndex)
{
	
	int i,j;
	unsigned short crc;
	unsigned char tBuffer[255];

	ss->rxPtr = 0;
	for(i = 0; i < 255; i++)
		ss->rxData[i] = 0x00; 


	/* for sync commands reset the deq bit   */
	if(cmd->CommandData[0] == ssp_CMD_SYNC) 
		systemPorts.sspPkt[portIndex].sspSeq[cmd->SSPAddress] = 0x80;

	/* update the log packet data before any encryption   */	
	sspInfo->Encrypted = cmd->EncryptionStatus; 
	sspInfo->PreEncryptedTransmit.PacketLength = cmd->CommandDataLength + 5;
	sspInfo->PreEncryptedTransmit.PacketData[0] = SSP_STX;					/* ssp packet start   */
	sspInfo->PreEncryptedTransmit.PacketData[1] = cmd->SSPAddress | systemPorts.sspPkt[portIndex].sspSeq[cmd->SSPAddress];//     sspSeq[cmd->SSPAddress];  /* the address/seq bit */ 
	sspInfo->PreEncryptedTransmit.PacketData[2] = cmd->CommandDataLength;    /* the data length only (always > 0)  */  
	for(i = 0; i < cmd->CommandDataLength; i++)  /* add the command data  */
		sspInfo->PreEncryptedTransmit.PacketData[3 + i] = cmd->CommandData[i]; 
	/* calc the packet CRC  (all bytes except STX)   */
	crc = cal_crc_loop_CCITT_A(cmd->CommandDataLength + 2,&sspInfo->PreEncryptedTransmit.PacketData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
	sspInfo->PreEncryptedTransmit.PacketData[3 + cmd->CommandDataLength] = (unsigned char)(crc & 0xFF);
	sspInfo->PreEncryptedTransmit.PacketData[4 + cmd->CommandDataLength] = (unsigned char)((crc >> 8) & 0xFF); 

	/* is this a encrypted packet  */
	if(cmd->EncryptionStatus){

		if(!EncryptSSPMultiplePortPacket(portIndex,cmd->SSPAddress,cmd->CommandData,cmd->CommandData,&cmd->CommandDataLength,&cmd->CommandDataLength,(unsigned __int64*)&cmd->Key))
			return 0;
		
	}

	/* create the packet from this data   */
	ss->CheckStuff = 0;
	ss->SSPAddress = cmd->SSPAddress;
	ss->rxPtr = 0;
	ss->txPtr = 0;
	ss->txBufferLength = cmd->CommandDataLength + 5;  /* the full ssp packet length   */
	ss->txData[0] = SSP_STX;					/* ssp packet start   */
	ss->txData[1] = cmd->SSPAddress | systemPorts.sspPkt[portIndex].sspSeq[cmd->SSPAddress];  /* the address/seq bit */ 
	ss->txData[2] = cmd->CommandDataLength;    /* the data length only (always > 0)  */  
	for(i = 0; i < cmd->CommandDataLength; i++)  /* add the command data  */
		ss->txData[3 + i] = cmd->CommandData[i]; 
	/* calc the packet CRC  (all bytes except STX)   */
	crc = cal_crc_loop_CCITT_A(ss->txBufferLength - 3,&ss->txData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
	ss->txData[3 + cmd->CommandDataLength] = (unsigned char)(crc & 0xFF);
	ss->txData[4 + cmd->CommandDataLength] = (unsigned char)((crc >> 8) & 0xFF);

	for(i = 0; i< ss->txBufferLength; i++)
		sspInfo->Transmit.PacketData[i] = ss->txData[i];
	sspInfo->Transmit.PacketLength = ss->txBufferLength;


	/* we now need to 'byte stuff' this buffered data   */
	j = 0;
	tBuffer[j++] = ss->txData[0];
	for(i = 1; i < ss->txBufferLength; i++){
		tBuffer[j] = ss->txData[i];
		if (ss->txData[i] ==	SSP_STX){
			tBuffer[++j] = SSP_STX;   /* SSP_STX found in data so add another to 'stuff it'  */
		}
		j++;
	}
	for(i = 0; i < j; i++)
		ss->txData[i] = tBuffer[i];
	ss->txBufferLength  = j;

	return 1;
}



int CompileSSPCommand(SSP_COMMAND* cmd,SSP_TX_RX_PACKET* ss,SSP_COMMAND_INFO* sspInfo)
{
	
	int i,j;
	unsigned short crc;
	unsigned char tBuffer[255];

	ss->rxPtr = 0;
	for(i = 0; i < 255; i++)
		ss->rxData[i] = 0x00; 






	/* for sync commands reset the deq bit   */
	if(cmd->CommandData[0] == ssp_CMD_SYNC) 
		sspSeq[cmd->SSPAddress] = 0x80;

	/* update the log packet data before any encryption   */	
	sspInfo->Encrypted = cmd->EncryptionStatus; 
	sspInfo->PreEncryptedTransmit.PacketLength = cmd->CommandDataLength + 5;
	sspInfo->PreEncryptedTransmit.PacketData[0] = SSP_STX;					/* ssp packet start   */
	sspInfo->PreEncryptedTransmit.PacketData[1] = cmd->SSPAddress | sspSeq[cmd->SSPAddress];  /* the address/seq bit */ 
	sspInfo->PreEncryptedTransmit.PacketData[2] = cmd->CommandDataLength;    /* the data length only (always > 0)  */  
	for(i = 0; i < cmd->CommandDataLength; i++)  /* add the command data  */
		sspInfo->PreEncryptedTransmit.PacketData[3 + i] = cmd->CommandData[i]; 
	/* calc the packet CRC  (all bytes except STX)   */
	crc = cal_crc_loop_CCITT_A(cmd->CommandDataLength + 2,&sspInfo->PreEncryptedTransmit.PacketData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
	sspInfo->PreEncryptedTransmit.PacketData[3 + cmd->CommandDataLength] = (unsigned char)(crc & 0xFF);
	sspInfo->PreEncryptedTransmit.PacketData[4 + cmd->CommandDataLength] = (unsigned char)((crc >> 8) & 0xFF); 

	/* is this a encrypted packet  */
	if(cmd->EncryptionStatus){

		if(!EncryptSSPPacket(cmd->SSPAddress ,cmd->CommandData,cmd->CommandData,&cmd->CommandDataLength,&cmd->CommandDataLength,(unsigned __int64*)&cmd->Key))
			return 0;
		
	}

	/* create the packet from this data   */
	ss->CheckStuff = 0;
	ss->SSPAddress = cmd->SSPAddress;
	ss->rxPtr = 0;
	ss->txPtr = 0;
	ss->txBufferLength = cmd->CommandDataLength + 5;  /* the full ssp packet length   */
	ss->txData[0] = SSP_STX;					/* ssp packet start   */
	ss->txData[1] = cmd->SSPAddress | sspSeq[cmd->SSPAddress];  /* the address/seq bit */ 
	ss->txData[2] = cmd->CommandDataLength;    /* the data length only (always > 0)  */  
	for(i = 0; i < cmd->CommandDataLength; i++)  /* add the command data  */
		ss->txData[3 + i] = cmd->CommandData[i]; 
	/* calc the packet CRC  (all bytes except STX)   */
	crc = cal_crc_loop_CCITT_A(ss->txBufferLength - 3,&ss->txData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);
	ss->txData[3 + cmd->CommandDataLength] = (unsigned char)(crc & 0xFF);
	ss->txData[4 + cmd->CommandDataLength] = (unsigned char)((crc >> 8) & 0xFF);

	for(i = 0; i< ss->txBufferLength; i++)
		sspInfo->Transmit.PacketData[i] = ss->txData[i];
	sspInfo->Transmit.PacketLength = ss->txBufferLength;


	/* we now need to 'byte stuff' this buffered data   */
	j = 0;
	tBuffer[j++] = ss->txData[0];
	for(i = 1; i < ss->txBufferLength; i++){
		tBuffer[j] = ss->txData[i];
		if (ss->txData[i] ==	SSP_STX){
			tBuffer[++j] = SSP_STX;   /* SSP_STX found in data so add another to 'stuff it'  */
		}
		j++;
	}
	for(i = 0; i < j; i++)
		ss->txData[i] = tBuffer[i];
	ss->txBufferLength  = j;

	return 1;
}


void SSPDataIn(unsigned char RxChar, SSP_TX_RX_PACKET* ss)
{
	unsigned short crc;


	if (RxChar == SSP_STX && ss->rxPtr == 0){
		// packet start
		ss->rxData[ss->rxPtr++] = RxChar;
	}else{
		// if last byte was start byte, and next is not then
		// restart the packet
		if (ss->CheckStuff == 1){
			if (RxChar != SSP_STX){
				ss->rxData[0] = SSP_STX;
				ss->rxData[1] = RxChar;  
				ss->rxPtr = 2;
			}else
				ss->rxData[ss->rxPtr++] = RxChar;
			// reset stuff check flag	
			ss->CheckStuff = 0; 		
		}else{
			// set flag for stuffed byte check
			if (RxChar == SSP_STX)
				ss->CheckStuff = 1;
			else{		
				// add data to packet
				ss->rxData[ss->rxPtr++] = RxChar;
				// get the packet length
				if (ss->rxPtr == 	3)
					ss->rxBufferLength = ss->rxData[2] + 5; 						
			}
		}
		// are we at the end of the packet
		if (ss->rxPtr  == ss->rxBufferLength ){
			// is this packet for us ??
			if ((ss->rxData[1] & SSP_STX) == ss->SSPAddress){
				// is the checksum correct
				crc = cal_crc_loop_CCITT_A(ss->rxBufferLength - 3,&ss->rxData[1] ,CRC_SSP_SEED,CRC_SSP_POLY);							
				if ((unsigned char)(crc & 0xFF) == ss->rxData[ss->rxBufferLength - 2] && (unsigned char)((crc >> 8) & 0xFF) == ss->rxData[ss->rxBufferLength - 1])
					ss->NewResponse = 1;  /* we have a new response so set flag  */
			}
			// reset packet 
			ss->rxPtr  = 0;	
			ss->CheckStuff = 0;		
		}				
	}	


}


NOMANGLE int CCONV DownloadFileToTarget(char* szFilename, int cPort, unsigned char sspAddress)
{

	int fh1,i;
	unsigned long numCurBytes;
	unsigned short dBlockSize;

	
		// get file handle and open file
	fh1 = _open(szFilename,_O_BINARY);
	if (fh1 == -1) return OPEN_FILE_ERROR;
	// some space for the data
	itlFile.fData = new unsigned char[_filelength(fh1)];  
	// read the file and store the data in the buffer
	if(_read(fh1,itlFile.fData,_filelength(fh1)) == 0) return READ_FILE_ERROR;
	// close the file
	_close(fh1);

	ramStatus.currentRamBlocks = 0;
	ramStatus.ramState = rmd_RAM_DOWNLOAD_IDLE;
	ramStatus.totalRamBlocks = 0;


	// check for ITL BV/SH type file
    if (itlFile.fData[0] == 'I' && itlFile.fData[1] == 'T' && itlFile.fData[2] == 'L') {

		 numCurBytes = 0;
		 for(i = 0; i <4; i++){
			numCurBytes += (unsigned long)itlFile.fData[17 + i] << (8*(3-i));
		 }
		  //get the block size from header
		 dBlockSize = (256*(unsigned short)itlFile.fData[0x3e]) + (unsigned short)itlFile.fData[0x3f];
		// correct for NV9 type
		 if(dBlockSize == 0) dBlockSize = 4096;
				
		  itlFile.NumberOfBlocks = numCurBytes / dBlockSize;
		  if(itlFile.NumberOfBlocks % dBlockSize != 0) itlFile.NumberOfBlocks += 1;
	}
	else{
		delete itlFile.fData;	
		return NOT_ITL_FILE;
	}

	/* check target connection   */
	sspC.BaudRate = 9600;
	sspC.PortNumber = cPort;
	sspC.RetryLevel = 2;
	sspC.SSPAddress = sspAddress;
	if( OpenSSPComPort(&sspC) == 0)
		return PORT_OPEN_FAIL;

	sspC.EncryptionStatus = 0;
	sspC.CommandDataLength = 1;
	sspC.CommandData[0]  = ssp_CMD_SYNC;
	
	if (SSPSendCommand(&sspC,&sspCmdInfo) == 0){
//		CloseSSPComPort();
		delete itlFile.fData;
		return SYNC_CONNECTION_FAIL;
	}
	if(sspC.ResponseData[0] != ssp_RSP_OK){
//		CloseSSPComPort();
		delete itlFile.fData;
		return SYNC_CONNECTION_FAIL;		
	}
	
	_beginthread(DownloadITLTarget,0,NULL); 

	return itlFile.NumberOfBlocks;


}


void DownloadITLTarget(void* data)
{
	unsigned int i,j;
	int numRamBlocks;
	SSP_TX_RX_PACKET sspd;
	clock_t curr_time,Dnl_Timeup;


	itlFile.NumberOfRamBytes = 0;
	for(i = 0; i < 4; i++)
		itlFile.NumberOfRamBytes += (unsigned long)itlFile.fData[7 + i] << (8 * (3-i));

	
	ramStatus.ramState = rmd_ESTABLISH_COMS;

	sspC.CommandDataLength = 2;
	sspC.CommandData[0] = ssp_CMD_PROGRAM_CMD;
	sspC.CommandData[1] = ssp_CMD_PROG_RAM;
	
	if (SSPSendCommand(&sspC,&sspCmdInfo) == 0){
//		CloseSSPComPort();
		delete itlFile.fData;
		_endthread();
		return;		
	}
	if(sspC.ResponseData[0] != ssp_RSP_OK){
//		CloseSSPComPort();
		delete itlFile.fData;
		_endthread();
		return;		
	}

	sspC.CommandDataLength = 128;
	for(i = 0 ; i < 128; i++)
		sspC.CommandData[i] = itlFile.fData[i];  
	
	if (SSPSendCommand(&sspC,&sspCmdInfo) == 0){
//		CloseSSPComPort();
		delete itlFile.fData;
		_endthread();
		return;		
	}
	if(sspC.ResponseData[0] != ssp_RSP_OK){
//		CloseSSPComPort();
		delete itlFile.fData;
		_endthread();
		return;		
	}

	/* checnge speed to download level   */
//	CloseSSPComPort();
	sspC.BaudRate = 38400;
	if( OpenSSPComPort(&sspC) == 0){
		_endthread();
		return;	
	}


	numRamBlocks = itlFile.NumberOfRamBytes/RAM_DWNL_BLOCK_SIZE;
	ramStatus.ramState = rmd_DOWNLOAD_RAM_FILE;
	ramStatus.totalRamBlocks = numRamBlocks;
	ramStatus.currentRamBlocks = 0;
	sspd.txBufferLength  = RAM_DWNL_BLOCK_SIZE;
	

	// get checksum for ram data
	RxVerify = TRUE;
	ChkSumRx = -1;	

	// we now have a validator set up ready to accept the RAM code
    // how many 128k blocks of RAM data to send (95,98 and ME cannot handle
	// very large buffer sizes !!!!
	for (i = 0; i < numRamBlocks; i++){
		ulCharsGone = 0;  // reset the tx chars counter
		for(j = 0; j < 128; j++)
			sspd.txData[i] = itlFile.fData[128 + (i*128) + j];
		if(!WritePort(&sspd)){
			RxVerify = false;
			_endthread(); 
			return;
		}
		Dnl_Timeup=clock()+(CLK_TCK * (MIN_DELAY_TIME));
		while(ulCharsGone < 1 && curr_time < Dnl_Timeup){Sleep(20); curr_time = clock();}; // wait for buffer to empty
		// check for time-out
		if (curr_time >= Dnl_Timeup){
			RxVerify = false;
			_endthread();
			return;
		}
		ramStatus.currentRamBlocks = i;
	}
	// any extra bytes??

	if (itlFile.NumberOfRamBytes % RAM_DWNL_BLOCK_SIZE != 0)
		  sspd.txBufferLength = (unsigned char)(itlFile.NumberOfRamBytes % RAM_DWNL_BLOCK_SIZE);
		  for(j = 0; j < itlFile.NumberOfRamBytes % RAM_DWNL_BLOCK_SIZE; j++)
			  sspd.txData[j] = itlFile.fData[128 + (i*128) + j];
	      if(!WritePort(&sspd)){
			 RxVerify = false;
			_endthread();	
			return;
	}
	// wait for buffer to empty
	Dnl_Timeup=clock()+(CLK_TCK * (MIN_DELAY_TIME));
	while(ulCharsGone < 1 && curr_time < Dnl_Timeup){Sleep(20); curr_time = clock();}; // wait for buffer to empty
	// check for timer out
	if (curr_time >= Dnl_Timeup){
		RxVerify = false;
		_endthread();
		return;
	}

	ramStatus.totalRamBlocks = 0;
	ramStatus.currentRamBlocks = 0;

	Dnl_Timeup=clock()+(CLK_TCK * (RAM_STARTUP_TIME));
	// wait for chksum return
	do{
		curr_time = clock();
		Sleep(10);
		if (curr_time > Dnl_Timeup){			
			// send update code to reset
			RxVerify = false;
			ChkSumRx = -1;
			_endthread();	
			return;
		}
	}while(ChkSumRx != (short)itlFile.fData[0x10]);  // check for valid sum

	ramStatus.ramState = rmd_INITIATE_UPDATE_CMD;



//	CloseSSPComPort();


	_endthread();
}





NOMANGLE long CCONV GetRamDownloadStatus(RAM_UPDATE_STATUS* rmData)
{

	rmData->currentRamBlocks = ramStatus.currentRamBlocks;
	rmData->ramState = ramStatus.ramState ;
	rmData->totalRamBlocks = ramStatus.totalRamBlocks ;


	return 1;
}



NOMANGLE int CCONV OpenSSPMulipleComPorts(PORT_CONFIG* pt)
{

	int i;

		
	for(i = 0; i < pt->NumberOfPorts; i++){
		systemPorts.PortID[i] = pt->PortID[i];
		OpenSystemPort(pt,i);
	}	
	systemPorts.NumberOfPorts = pt->NumberOfPorts; 


	return 1;
}


int OpenSystemPort(PORT_CONFIG* pt, unsigned char portIndex)
{

	COMMTIMEOUTS CommTimeouts;
	char szCom[20];  // for COM
	char openTry;
	DCB Dcb;



	// check for port already open
	if(systemPorts.PortStatus[portIndex] == PORT_OPEN)
		return 1;
		
	SetOS();

	if (pt->PortID[portIndex]  > 9)
		wsprintf(szCom,"\\\\.\\COM%d",pt->PortID[portIndex]); // format device name as COMx
	else 
		wsprintf(szCom,"COM%d",pt->PortID[portIndex]); 


	// retry loop as to make sure dual core processors open OK
	openTry = 0;
	do{
		if (OS==W_NT) 
			    systemPorts.PortHandles[portIndex] = CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				FILE_FLAG_OVERLAPPED, // file attributes 
				NULL);         // handle of file with attributes to copy

		else if ((OS==W_95) || (OS==W_32s))
			    systemPorts.PortHandles[portIndex] = CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				0,			   // file attributes
				NULL);         // handle of file with attributes to copy
	
				Sleep(100);

	}while(systemPorts.PortHandles[portIndex]==INVALID_HANDLE_VALUE && openTry++ < 5);
	/* check for valid handle  */
	if (systemPorts.PortHandles[portIndex] == INVALID_HANDLE_VALUE)
	{
		systemPorts.PortStatus[portIndex] = PORT_ERROR;
		return 0;
	}

	// Set the queue sizes
	if (!SetupComm(systemPorts.PortHandles[portIndex],1024,1024)) // if not successful
	{
		CloseSystemPort(portIndex);
		systemPorts.PortStatus[portIndex] = PORT_ERROR;
		return 0;
	}

	// initialise some timeouts, otherwise unpredictable results
	memset(&CommTimeouts,0,sizeof(CommTimeouts));
	CommTimeouts.ReadIntervalTimeout=MAXDWORD;		// to allow ReadFile to return immediately 
	CommTimeouts.ReadTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.ReadTotalTimeoutConstant=0;		// !used 
	CommTimeouts.WriteTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.WriteTotalTimeoutConstant=0;		// !used 
	SetCommTimeouts(hDevice,&CommTimeouts);
	// set the event mask for notification of certain comms events
	SetCommMask(systemPorts.PortHandles[portIndex],EV_RXCHAR | EV_TXEMPTY);

	if (!GetCommState(systemPorts.PortHandles[portIndex],&Dcb))   // get default state
	{
	    CloseSystemPort(portIndex);
		systemPorts.PortStatus[portIndex] = PORT_ERROR;
		return 0;
	}

    Dcb.BaudRate=pt->BaudRate[portIndex]; 
	Dcb.ByteSize=8;   
	Dcb.Parity=NOPARITY;
    Dcb.StopBits=TWOSTOPBITS;

	// apply new settings
	if (!SetCommState(systemPorts.PortHandles[portIndex],&Dcb))   // set new state
	{
		CloseSystemPort(portIndex);
		systemPorts.PortStatus[portIndex] = PORT_ERROR;
		return 0;
	}

	systemPorts.PortActive[portIndex] = 1; // to allow a comms event notification thread to run

	_beginthread((*evThread[portIndex]), // address of our thread routine (functiom pointer)
					 0,  // default stacksize
					 NULL); // args to pass to routine
	

	systemPorts.PortStatus[portIndex] = PORT_OPEN;

	return 1;

}



NOMANGLE int CCONV CloseSSPMultiplePorts(void)
{
	int i;



	for(i = 0; i < systemPorts.NumberOfPorts; i++){
		CloseSystemPort(i);
	}

	systemPorts.NumberOfPorts = 0;

	return 1;
}



int CloseSystemPort(unsigned char portIndex)
{
	clock_t delayTime, current_time;

	systemPorts.PortActive[portIndex] = 0;

	/*
	delayTime = clock()+(CLK_TCK * (MIN_DELAY_TIME));
	current_time = clock();
	while(current_time < delayTime){
			Sleep(20); 
			current_time = clock();
	}; */// a delay to allow thread to terminate

	if(systemPorts.PortStatus[portIndex]!= PORT_CLOSED){
		CloseHandle(systemPorts.PortHandles[portIndex]);
		systemPorts.PortStatus[portIndex] = PORT_CLOSED;
	}

	systemPorts.PortHandles[portIndex] = 0;

	

	return 1;

}



void EventNotifyMultiple0(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[0]){
			WaitCommEvent(systemPorts.PortHandles[0] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[0] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					SSPDataIn(ReadPortMultiple(0), &systemPorts.sspPkt[0]);

					ClearCommError (systemPorts.PortHandles[0] ,&dwError,&cs);
				}
			}
	}
	
	_endthread();

}

void EventNotifyMultiple1(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[1]){
			WaitCommEvent(systemPorts.PortHandles[1] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[1] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(1), &systemPorts.sspPkt[1]);

					ClearCommError (systemPorts.PortHandles[1] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple2(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[2]){
			WaitCommEvent(systemPorts.PortHandles[2] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[2] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(2), &systemPorts.sspPkt[2]);

					ClearCommError (systemPorts.PortHandles[2] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple3(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[3]){
			WaitCommEvent(systemPorts.PortHandles[3] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[3] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(3), &systemPorts.sspPkt[3]);

					ClearCommError (systemPorts.PortHandles[3] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple4(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[4]){
			WaitCommEvent(systemPorts.PortHandles[4] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[4] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(4), &systemPorts.sspPkt[4]);

					ClearCommError (systemPorts.PortHandles[4] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple5(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[5]){
			WaitCommEvent(systemPorts.PortHandles[5] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[5] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(5), &systemPorts.sspPkt[5]);

					ClearCommError (systemPorts.PortHandles[5] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple6(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[6]){
			WaitCommEvent(systemPorts.PortHandles[6] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[6] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(6), &systemPorts.sspPkt[6]);

					ClearCommError (systemPorts.PortHandles[6] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple7(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[7]){
			WaitCommEvent(systemPorts.PortHandles[7] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[7] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(7), &systemPorts.sspPkt[7]);

					ClearCommError (systemPorts.PortHandles[7] ,&dwError,&cs);
				}
			}
	}
	
	_endthread();

}
void EventNotifyMultiple8(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[8]){
			WaitCommEvent(systemPorts.PortHandles[8] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[8] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(8), &systemPorts.sspPkt[8]);

					ClearCommError (systemPorts.PortHandles[8] ,&dwError,&cs);
				}
			}
	}
	
	_endthread();

}
void EventNotifyMultiple9(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[9]){
			WaitCommEvent(systemPorts.PortHandles[9] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[9] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(9), &systemPorts.sspPkt[9]);

					ClearCommError (systemPorts.PortHandles[9] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple10(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[10]){
			WaitCommEvent(systemPorts.PortHandles[10] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[10] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(10), &systemPorts.sspPkt[10]);

					ClearCommError (systemPorts.PortHandles[10] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple11(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[11]){
			WaitCommEvent(systemPorts.PortHandles[11] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[11] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(11), &systemPorts.sspPkt[11]);

					ClearCommError (systemPorts.PortHandles[11] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple12(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[12]){
			WaitCommEvent(systemPorts.PortHandles[12] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[12] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(12), &systemPorts.sspPkt[12]);

					ClearCommError (systemPorts.PortHandles[12] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple13(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[13]){
			WaitCommEvent(systemPorts.PortHandles[13] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[13] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(13), &systemPorts.sspPkt[13]);

					ClearCommError (systemPorts.PortHandles[13] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple14(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[14]){
			WaitCommEvent(systemPorts.PortHandles[14] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[14] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(14), &systemPorts.sspPkt[14]);

					ClearCommError (systemPorts.PortHandles[14] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple15(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[15]){
			WaitCommEvent(systemPorts.PortHandles[15] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[15] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(15), &systemPorts.sspPkt[15]);

					ClearCommError (systemPorts.PortHandles[15] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple16(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[16]){
			WaitCommEvent(systemPorts.PortHandles[16] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[16] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(16), &systemPorts.sspPkt[16]);

					ClearCommError (systemPorts.PortHandles[16] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple17(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[17]){
			WaitCommEvent(systemPorts.PortHandles[17] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[17] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(17), &systemPorts.sspPkt[17]);

					ClearCommError (systemPorts.PortHandles[17] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple18(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[18]){
			WaitCommEvent(systemPorts.PortHandles[18] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[18] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(18), &systemPorts.sspPkt[18]);

					ClearCommError (systemPorts.PortHandles[18] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}
void EventNotifyMultiple19(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;
int i;

	while(systemPorts.PortActive[19]){
			WaitCommEvent(systemPorts.PortHandles[19] ,&dwEvent,NULL);
			ClearCommError (systemPorts.PortHandles[19] ,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){
				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortMultiple(19), &systemPorts.sspPkt[19]);

					ClearCommError (systemPorts.PortHandles[19] ,&dwError,&cs);
				}
			}

	}
	
	_endthread();

}


///////////////////////////////////////






NOMANGLE int CCONV OpenSSPComPort(SSP_COMMAND* cmd)
{
COMMTIMEOUTS CommTimeouts;
char szCom[20];  // for COM
char openTry;
DCB Dcb;

	/* if port already open then come out   */
	if(PortStatus == PORT_OPEN)
		return 1;

	SetOS();

	if (cmd->PortNumber >9)
		wsprintf(szCom,"\\\\.\\COM%d",cmd->PortNumber ); // format device name as COMx
	else 
		wsprintf(szCom,"COM%d",cmd->PortNumber ); // format device name as COMx

	// retry loop as to make sure dual core processors open OK
	openTry = 0;
	do{
		if (OS==W_NT) 
			hDevice=CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				FILE_FLAG_OVERLAPPED, // file attributes 
				NULL);         // handle of file with attributes to copy

		else if ((OS==W_95) || (OS==W_32s))
			hDevice=CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				0,			   // file attributes
				NULL);         // handle of file with attributes to copy
	
				Sleep(100);

	}while(hDevice==INVALID_HANDLE_VALUE && openTry++ < 5);

	if (hDevice==INVALID_HANDLE_VALUE)
	{
		   
		if(cmd->IgnoreError == 0) MessageBox(0,"Unable To open this port",
	   szCom,MB_OK | MB_ICONEXCLAMATION);
		PortStatus = PORT_ERROR;
		return 0;
	}


// First setup the queue sizes
	if (!SetupComm(hDevice,1024,1024)) // if not successful
	{
		PortStatus = PORT_ERROR;
		return 0;
	}

// initialise some timeouts, otherwise unpredictable results
	memset(&CommTimeouts,0,sizeof(CommTimeouts));
	CommTimeouts.ReadIntervalTimeout=MAXDWORD;		// to allow ReadFile to return immediately 
	CommTimeouts.ReadTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.ReadTotalTimeoutConstant=0;		// !used 
	CommTimeouts.WriteTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.WriteTotalTimeoutConstant=0;		// !used 
	SetCommTimeouts(hDevice,&CommTimeouts);
	// set the event mask for notification of certain comms events
	SetCommMask(hDevice,EV_RXCHAR | EV_TXEMPTY);

	if (!GetCommState(hDevice,&Dcb))   // get default state
	{
		CloseSSPComPort();
		PortStatus = PORT_ERROR;
		return 0;
	}

    Dcb.BaudRate=cmd->BaudRate; 
	Dcb.ByteSize=8;   
	Dcb.Parity=NOPARITY;
    Dcb.StopBits=TWOSTOPBITS;

	// apply new settings
	if (!SetCommState(hDevice,&Dcb))   // set new state

	{
		CloseSSPComPort();
		if(cmd->IgnoreError == 0) MessageBox(GetFocus(),"Error setting new comms params","SetupComm",MB_OK | MB_ICONEXCLAMATION);
		PortStatus = PORT_ERROR;
		return 0;
	}



	bActive =TRUE; // to allow a comms event notification thread to run
	_beginthread(EventNotify, // address of our thread routine
				 0,  // default stacksize
				 NULL); // args to pass to routine


	PortStatus = PORT_OPEN;


	return 1;
}




void EventNotify(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;


	while(bActive){
			WaitCommEvent(hDevice,&dwEvent,NULL);
			ClearCommError (hDevice,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){


				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPort(), &ssp);
					else
						ChkSumRx = ReadPort();

					ClearCommError (hDevice,&dwError,&cs);
				}
			}

			if (dwEvent & EV_TXEMPTY)
				ulCharsGone = 1;

	}

   _endthread();
	
  
} 

void EventNotify2(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;


	while(bActive2){
			WaitCommEvent(hDevice2,&dwEvent,NULL);
			ClearCommError (hDevice2,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){


				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPort2(),&ssp2);
					else
						ChkSumRx = ReadPort2();

					ClearCommError (hDevice2,&dwError,&cs);
				}
			}

			if (dwEvent & EV_TXEMPTY)
				ulCharsGone = 1;

	}

   _endthread();
	
  
} 


void EventNotifyUSB(PVOID)
{
DWORD dwEvent,dwError;
COMSTAT cs;


	while(bActiveUSB){
			WaitCommEvent(hDeviceUSB,&dwEvent,NULL);
			ClearCommError (hDeviceUSB,&dwError,&cs);
			if (dwEvent & EV_RXCHAR){


				while (cs.cbInQue){
					if(!RxVerify)
						SSPDataIn(ReadPortUSB(),&sspUSB);
					else
						ChkSumRx = ReadPortUSB();

					ClearCommError (hDeviceUSB,&dwError,&cs);
				}
			}

			if (dwEvent & EV_TXEMPTY)
				ulCharsGone = 1;

	}

   _endthread();
	
  
} 

NOMANGLE int CCONV OpenSSPComPort2(SSP_COMMAND* cmd)
{
COMMTIMEOUTS CommTimeouts;
char szCom[20];  // for COM
char openTry;
DCB Dcb;

	/* if port already open then come out   */
	if(PortStatus2 == PORT_OPEN)
		return 1;

	SetOS();

	if (cmd->PortNumber >9)
		wsprintf(szCom,"\\\\.\\COM%d",cmd->PortNumber ); // format device name as COMx
	else 
		wsprintf(szCom,"COM%d",cmd->PortNumber ); // format device name as COMx

	// retry loop as to make sure dual core processors open OK
	openTry = 0;
	do{
		if (OS==W_NT) 
			hDevice2=CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				FILE_FLAG_OVERLAPPED, // file attributes 
				NULL);         // handle of file with attributes to copy

		else if ((OS==W_95) || (OS==W_32s))
			hDevice2=CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				0,			   // file attributes
				NULL);         // handle of file with attributes to copy
	
				Sleep(100);

	}while(hDevice2==INVALID_HANDLE_VALUE && openTry++ < 5);

	if (hDevice2==INVALID_HANDLE_VALUE)
	{
		   
		if(cmd->IgnoreError == 0) MessageBox(0,"Unable To open this port",
	   szCom,MB_OK | MB_ICONEXCLAMATION);
		PortStatus2 = PORT_ERROR;
		return 0;
	}


// First setup the queue sizes
	if (!SetupComm(hDevice2,1024,1024)) // if not successful
	{
		PortStatus2 = PORT_ERROR;
		return 0;
	}

// initialise some timeouts, otherwise unpredictable results
	memset(&CommTimeouts,0,sizeof(CommTimeouts));
	CommTimeouts.ReadIntervalTimeout=MAXDWORD;		// to allow ReadFile to return immediately 
	CommTimeouts.ReadTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.ReadTotalTimeoutConstant=0;		// !used 
	CommTimeouts.WriteTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.WriteTotalTimeoutConstant=0;		// !used 
	SetCommTimeouts(hDevice2,&CommTimeouts);
	// set the event mask for notification of certain comms events
	SetCommMask(hDevice2,EV_RXCHAR | EV_TXEMPTY);

	if (!GetCommState(hDevice2,&Dcb))   // get default state
	{
		CloseSSPComPort2();
		PortStatus2 = PORT_ERROR;
		return 0;
	}

    Dcb.BaudRate=cmd->BaudRate; 
	Dcb.ByteSize=8;   
	Dcb.Parity=NOPARITY;
    Dcb.StopBits=TWOSTOPBITS;

	// apply new settings
	if (!SetCommState(hDevice2,&Dcb))   // set new state

	{
		CloseSSPComPort2();
		if(cmd->IgnoreError == 0) MessageBox(GetFocus(),"Error setting new comms params","SetupComm",MB_OK | MB_ICONEXCLAMATION);
		PortStatus2 = PORT_ERROR;
		return 0;
	}



	bActive2 =TRUE; // to allow a comms event notification thread to run
	_beginthread(EventNotify2, // address of our thread routine
				 0,  // default stacksize
				 NULL); // args to pass to routine


	PortStatus2 = PORT_OPEN;


	return 1;
}



NOMANGLE int CCONV OpenSSPComPortUSB(SSP_COMMAND* cmd)
{
COMMTIMEOUTS CommTimeouts;
char szCom[20];  // for COM
char openTry;
DCB Dcb;

	/* if port already open then come out   */
	if(PortStatusUSB == PORT_OPEN)
		return 1;

	SetOS();

	if (cmd->PortNumber >9)
		wsprintf(szCom,"\\\\.\\COM%d",cmd->PortNumber ); // format device name as COMx
	else 
		wsprintf(szCom,"COM%d",cmd->PortNumber ); // format device name as COMx

	// retry loop as to make sure dual core processors open OK
	openTry = 0;
	do{
		if (OS==W_NT) 
			hDeviceUSB=CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				FILE_FLAG_OVERLAPPED, // file attributes 
				NULL);         // handle of file with attributes to copy

		else if ((OS==W_95) || (OS==W_32s))
			hDeviceUSB=CreateFile(szCom, // name of device
				GENERIC_READ | GENERIC_WRITE, // access mode
				0,             // exclusive access
				NULL,          // address of security desriptor
				OPEN_EXISTING, // how to create
				0,			   // file attributes
				NULL);         // handle of file with attributes to copy
	
				Sleep(100);

	}while(hDeviceUSB==INVALID_HANDLE_VALUE && openTry++ < 5);

	if (hDeviceUSB==INVALID_HANDLE_VALUE)
	{
		   
		if(cmd->IgnoreError == 0) MessageBox(0,"Unable To open this port",
	   szCom,MB_OK | MB_ICONEXCLAMATION);
		PortStatusUSB = PORT_ERROR;
		return 0;
	}


// First setup the queue sizes
	if (!SetupComm(hDeviceUSB,1024,1024)) // if not successful
	{
		PortStatusUSB = PORT_ERROR;
		return 0;
	}

// initialise some timeouts, otherwise unpredictable results
	memset(&CommTimeouts,0,sizeof(CommTimeouts));
	CommTimeouts.ReadIntervalTimeout=MAXDWORD;		// to allow ReadFile to return immediately 
	CommTimeouts.ReadTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.ReadTotalTimeoutConstant=0;		// !used 
	CommTimeouts.WriteTotalTimeoutMultiplier=0;		// !used 
	CommTimeouts.WriteTotalTimeoutConstant=0;		// !used 
	SetCommTimeouts(hDeviceUSB,&CommTimeouts);
	// set the event mask for notification of certain comms events
	SetCommMask(hDeviceUSB,EV_RXCHAR | EV_TXEMPTY);

	if (!GetCommState(hDeviceUSB,&Dcb))   // get default state
	{
		CloseSSPComPortUSB();
		PortStatusUSB = PORT_ERROR;
		return 0;
	}

    Dcb.BaudRate=cmd->BaudRate; 
	Dcb.ByteSize=8;   
	Dcb.Parity=NOPARITY;
    Dcb.StopBits=TWOSTOPBITS;

	// apply new settings
	if (!SetCommState(hDeviceUSB,&Dcb))   // set new state

	{
		CloseSSPComPortUSB();
		if(cmd->IgnoreError == 0) MessageBox(GetFocus(),"Error setting new comms params","SetupComm",MB_OK | MB_ICONEXCLAMATION);
		PortStatusUSB = PORT_ERROR;
		return 0;
	}



	bActiveUSB =TRUE; // to allow a comms event notification thread to run
	_beginthread(EventNotifyUSB, // address of our thread routine
				 0,  // default stacksize
				 NULL); // args to pass to routine
	

	PortStatusUSB = PORT_OPEN;


	return 1;
}


NOMANGLE int CCONV CloseSSPComPort(void)
{



		bActive = FALSE;


		if(PortStatus != PORT_CLOSED){
			PortStatus = PORT_CLOSED;
			CloseHandle(hDevice);
		}


	return 1;

}	


NOMANGLE int CCONV CloseSSPComPort2(void)
{



		bActive2 = FALSE;


		if(PortStatus2 != PORT_CLOSED){
			PortStatus2 = PORT_CLOSED;
			CloseHandle(hDevice2);
		}


	return 1;

}	


NOMANGLE int CCONV CloseSSPComPortUSB(void)
{


		bActiveUSB = FALSE;


		if(PortStatusUSB != PORT_CLOSED){
			PortStatusUSB = PORT_CLOSED;
			CloseHandle(hDeviceUSB);
		}


	return 1;

}	


BOOL WritePortMultiple(SSP_TX_RX_PACKET* ss, unsigned char portIndex)
{
ULONG ulBytesWritten;			// buffer for bytes written count
DWORD dwError;


// overlapped structure not supported in Win95
	if (OS==W_NT)
	{ 
		oNotify.Offset=0;		// start of transfer
		oNotify.OffsetHigh=0;   // start of transfer
		if (!WriteFile(systemPorts.PortHandles[portIndex],	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			&oNotify))		// address of overlapped structure
		{
			dwError=GetLastError();
			// ok for overlapped error
			if(dwError == ERROR_IO_PENDING)
				return TRUE;
			else
				return FALSE;	
		}
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		if (!WriteFile(systemPorts.PortHandles[portIndex],	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength ,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			NULL))			// address of overlapped structure
		{
			dwError = GetLastError();
				return FALSE;
		}
	}

	return TRUE;
}


BOOL WritePort(SSP_TX_RX_PACKET* ss){
ULONG ulBytesWritten;			// buffer for bytes written count
DWORD dwError;


// overlapped structure not supported in Win95
	if (OS==W_NT)
	{ 
		oNotify.Offset=0;		// start of transfer
		oNotify.OffsetHigh=0;   // start of transfer
		if (!WriteFile(hDevice,	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			&oNotify))		// address of overlapped structure
		{
			dwError=GetLastError();
			// ok for overlapped error
			if(dwError == ERROR_IO_PENDING)
				return TRUE;
			else
				return FALSE;	
		}
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		if (!WriteFile(hDevice,	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength ,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			NULL))			// address of overlapped structure
		{
			dwError = GetLastError();
				return FALSE;
		}
	}

	return TRUE;
}



BOOL WritePort2(SSP_TX_RX_PACKET* ss){
ULONG ulBytesWritten;			// buffer for bytes written count
DWORD dwError;


// overlapped structure not supported in Win95
	if (OS==W_NT)
	{ 
		oNotify.Offset=0;		// start of transfer
		oNotify.OffsetHigh=0;   // start of transfer
		if (!WriteFile(hDevice2,	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			&oNotify))		// address of overlapped structure
		{
			dwError=GetLastError();
			// ok for overlapped error
			if(dwError == ERROR_IO_PENDING)
				return TRUE;
			else
				return FALSE;	
		}
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		if (!WriteFile(hDevice2,	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength ,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			NULL))			// address of overlapped structure
		{
			dwError = GetLastError();
				return FALSE;
		}
	}

	return TRUE;
}


BOOL WritePortUSB(SSP_TX_RX_PACKET* ss){
ULONG ulBytesWritten;			// buffer for bytes written count
DWORD dwError;


// overlapped structure not supported in Win95
	if (OS==W_NT)
	{ 
		oNotify.Offset=0;		// start of transfer
		oNotify.OffsetHigh=0;   // start of transfer
		if (!WriteFile(hDeviceUSB,	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			&oNotify))		// address of overlapped structure
		{
			dwError=GetLastError();
			// ok for overlapped error
			if(dwError == ERROR_IO_PENDING)
				return TRUE;
			else
				return FALSE;	
		}
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		if (!WriteFile(hDeviceUSB,	// handle of device
			ss->txData,			// string to write
			ss->txBufferLength ,				// number of bytes to write
			&ulBytesWritten,	// number of bytes written
			NULL))			// address of overlapped structure
		{
			dwError = GetLastError();
				return FALSE;
		}
	}

	return TRUE;
}


unsigned char ReadPortMultiple(unsigned char portIndex)
{
ULONG ulBytesRead;      // no. of bytes read var
unsigned char readbyte;

	readbyte = 0;

	if (OS==W_NT)
	{
		ReadFile(systemPorts.PortHandles[portIndex],	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				&oNotify);		// overlapped structure
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		ReadFile(systemPorts.PortHandles[portIndex],	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				NULL);		// overlapped structure
	}
	
	return readbyte;
}


unsigned char ReadPort(void){
ULONG ulBytesRead;      // no. of bytes read var
unsigned char readbyte;

	readbyte = 0;

	if (OS==W_NT)
	{
		ReadFile(hDevice,	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				&oNotify);		// overlapped structure
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		ReadFile(hDevice,	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				NULL);		// overlapped structure
	}
	
	return readbyte;
}


unsigned char ReadPort2(void){
ULONG ulBytesRead;      // no. of bytes read var
unsigned char readbyte;

	readbyte = 0;

	if (OS==W_NT)
	{
		ReadFile(hDevice2,	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				&oNotify);		// overlapped structure
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		ReadFile(hDevice2,	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				NULL);		// overlapped structure
	}
	
	return readbyte;
}


unsigned char ReadPortUSB(void){
ULONG ulBytesRead;      // no. of bytes read var
unsigned char readbyte;

	readbyte = 0;

	if (OS==W_NT)
	{
		ReadFile(hDeviceUSB,	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				&oNotify);		// overlapped structure
	}
	else if ((OS==W_95) || (OS==W_32s))
	{
		ReadFile(hDeviceUSB,	    // handle to device
				&readbyte,	// input buffer
				1,			// no. of bytes to read
				&ulBytesRead,// no. of bytes read
				NULL);		// overlapped structure
	}
	
	return readbyte;
}



void SetOS(void){
	OSVERSIONINFO VerInfo;  // OS version information structure
		// get the OS info
	VerInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (!GetVersionEx(&VerInfo))
	{
		MessageBox(GetFocus(),"Unable To Determine OS","Set OS",MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	switch(VerInfo.dwPlatformId)
	{
		case VER_PLATFORM_WIN32_WINDOWS:
			OS=W_95;
			break;
		case VER_PLATFORM_WIN32_NT:
			OS=W_NT;
			break;
		case VER_PLATFORM_WIN32s:
			OS=W_32s;
			break;
	}
}
