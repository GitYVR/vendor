// ITLSSPProc.cpp : Defines the entry point for the DLL application.
//

#define CCONV _stdcall
#define NOMANGLE

#include "stdafx.h"
#include "ITLSSPProc.h"
#include <stdlib.h>
#include "random.h"
#include "encryption.h"
#include <time.h>


#define VER_MAJ  1  // not > 255
#define VER_MIN	 2	// not > 255
#define VER_REV	 6	// not > 255


unsigned int encPktCount[MAX_SSP_PORT];
extern unsigned char sspSeq[MAX_SSP_PORT];
extern bool bActive,bActive2,bActiveUSB;
extern int PortStatus,PortStatus2,PortStatusUSB;
extern HANDLE hDevice,hDevice2,hDeviceUSB;	
extern SYSTEM_PORTS systemPorts;

/*		Linear Feedback Shift Registers			*/
#define LFSR(n)    {if (n&1) n=((n^0x80000055)>>1)|0x80000000; else n>>=1;}
/*		Rotate32								*/
#define ROT(x, y)  (x=(x<<y)|(x>>(32-y)))



BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	int i,j;

    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			for(i = 0; i < MAX_SSP_PORT; i++){
				encPktCount[i] = 0;
				sspSeq[i] = 0x80;
			}
			// initialise the system ports;
			systemPorts.NumberOfPorts = 0;
			for(i= 0; i < MAX_PORT_ID;i ++){
				systemPorts.PortHandles[i] = 0;
				systemPorts.PortID[i] = 0;
				systemPorts.PortStatus[i] = PORT_CLOSED; 
				systemPorts.PortActive[i] = 0; 
				for(j = 0; j < MAX_SSP_ADDRESS; j++){
					systemPorts.sspPkt[i].encPktCount[j] = 0;
					systemPorts.sspPkt[i].sspSeq[j] = 0x80;
				}
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			bActive = FALSE;
			if(PortStatus != 0){
				PortStatus = 0;
				CloseHandle(hDevice);
			}
			bActive2 = FALSE;
			if(PortStatus2 != 0){
				PortStatus2 = 0;
				CloseHandle(hDevice2);
			}
			bActiveUSB= FALSE;
			if(PortStatusUSB != 0){
				PortStatusUSB = 0;
				CloseHandle(hDeviceUSB);
			}
			for(i = 0; i < MAX_SSP_PORT; i++){
				systemPorts.PortActive[i] = 0;
				if(systemPorts.PortStatus[i] != 0)
					CloseHandle(systemPorts.PortHandles[i]); 
				
				systemPorts.PortStatus[i] = PORT_CLOSED;
			}

			break;
    }
    return TRUE;
}


typedef enum{
	KEY_GENERATOR,
	KEY_MODULUS,
	KEY_HOST_INTER,
	KEY_HOST_RANDOM,
	KEY_SLAVE_INTER,
	KEY_SLAVE_RANDOM,
	KEY_HOST,
	KEY_SLAVE,
}SSP_KEY_INDEX;






NOMANGLE int CCONV GetProcDLLVersion(unsigned char* ver)
{
	ver[0] = VER_MAJ;
	ver[1] = VER_MIN;
	ver[2] = VER_REV;

	return 1;

}


NOMANGLE int CCONV TestSplit(PAY* py,UINT32 valueToFind)
{
			
	INT16 i,nxt,cIndex,j;
	UINT32 newQty;
	INT32 valFind;
	UINT8 levelTest,curMatch;
	

	

	/* clear down the quantity array   */
	for(i = 0; i < py->NumberOfCoinValues; i++)
			py->SplitQty[i] = 0;
  cIndex = 255;
	/* we need this as a signed value < 0 indicates a split not possible later  */
	valFind = (INT32)valueToFind;
	
	/* first run through top to bottom for a simple top down value spilt  */
	if(py->Mode == FLOAT_PAYOUT_TO_PAYOUT){
		for(i = py->NumberOfCoinValues - 1; i >= 0; i--){
			  curMatch = 1;  /* is this coin our country code */
			  for(j = 0; j < 3; j++){
			  	if(py->PayoutCountryReq[j] != py->CoinsInHopper[i].CountryCode[j])
			  		curMatch = 0;
			  } 
			  if(curMatch){  
					/* is this value for payout  */
					if(py->FloatMode[i] == FLOAT_PAYOUT_TO_PAYOUT){
					    newQty = valFind/py->CoinsInHopper[i].CoinValue;
				 		if(newQty){
				 			py->SplitQty[i] = newQty;
				 			/* clamp to level  */
				 			if(py->SplitQty[i] >= py->CoinsInHopper[i].CoinLevel)
				 				py->SplitQty[i] = py->CoinsInHopper[i].CoinLevel;
				 			
				 			valFind -= py->SplitQty[i] *  py->CoinsInHopper[i].CoinValue;
				 		}
				}
			}
		}	
	}
	/* have we found a simple split ? */
	if(valFind == 0)
		return (UINT32)valFind;
	
	/* clear down the quantity array   */
	for(i = 0; i < py->NumberOfCoinValues; i++)
			py->SplitQty[i] = 0;
  cIndex = 255;
	/* we need this as a signed value < 0 indicates a split not possible later  */
	valFind = (INT32)valueToFind;	
	
	/* start from lowest value checking the modulus status of next coin to determine this coin qty required */
	for(i = 0; i < py->NumberOfCoinValues; i++){
		
	  curMatch = 1;  /* is this coin our country code */
	  for(j = 0; j < 3; j++){
	  	if(py->PayoutCountryReq[j] != py->CoinsInHopper[i].CountryCode[j])
	  		curMatch = 0;
	  } 		
	
		if (curMatch && (py->Mode == FLOAT_PAYOUT_TO_CASHBOX || (py->FloatMode[i] == FLOAT_PAYOUT_TO_PAYOUT && py->FloatMode[i + 1] == FLOAT_PAYOUT_TO_PAYOUT) )){
			nxt = 0; /* clear flag */
			do{
				/* increment the quantity for this coin until the amount required has zero modulus with the next highest */
				newQty = py->SplitQty[i] * py->CoinsInHopper[i].CoinValue;
				newQty = valFind - newQty; 
				if(i < py->NumberOfCoinValues - 1){
					if(newQty % py->CoinsInHopper[i + 1].CoinValue == 0)
							nxt = 1;
					else{ /* do we have enough coins at this level to satisfy the requirement ? */
							if(py->SplitQty[i] >= py->CoinsInHopper[i].CoinLevel)
								nxt = 1;
							else
								py->SplitQty[i]++; /* increment the number of coins for this value required */		
					}
				}else{
						if(newQty == 0)
							nxt = 1;
						else{
							if(py->SplitQty[i] >= py->CoinsInHopper[i].CoinLevel)
								nxt = 1;
							else
								py->SplitQty[i]++; /* increment the number of coins for this value required */		
						}				
					
				}
				/* SPECIAL CASE: test if we have an exact value for low payouts, we can use this later if no further split possible  */
				if(py->SplitQty[i] * py->CoinsInHopper[i].CoinValue == valueToFind){
						cIndex = i;
				}
				
			}while(nxt == 0);
			/* reduce the value to find  */
			valFind = valFind - (INT32)(py->SplitQty[i] * py->CoinsInHopper[i].CoinValue);
		}
	}
	/* if less than zero, we cannot make a split for this value with the coins we have  */
	if(valFind < 0){
		/* clear down the quantity array   */
		for(i = 0; i < py->NumberOfCoinValues; i++)
				py->SplitQty[i] = 0;		
		if(cIndex< 255){ /* we had a valid single value payout from before so use this  */
				py->SplitQty[cIndex] = (valueToFind/py->CoinsInHopper[cIndex].CoinValue);
				return 0;
		}else{
			/* last resort ! - test full requirement from highest to lowest to see if we can do it that way */
			valFind = (INT32)valueToFind;
			for(i = py->NumberOfCoinValues - 1; i >= 0; i--){				
			  curMatch = 1;  /* is this coin our country code */
			  for(j = 0; j < 3; j++){
			  	if(py->PayoutCountryReq[j] != py->CoinsInHopper[i].CountryCode[j])
			  		curMatch = 0;
			  } 														
				if(curMatch && (py->CoinsInHopper[i].CoinLevel && (py->Mode == FLOAT_PAYOUT_TO_CASHBOX || py->FloatMode[i] == FLOAT_PAYOUT_TO_PAYOUT))){
						py->SplitQty[i] = valFind/py->CoinsInHopper[i].CoinValue;
						if(py->LevelMode == LEVEL_CHECK_ON){
							if(py->SplitQty[i] > py->CoinsInHopper[i].CoinLevel)
									py->SplitQty[i] = py->CoinsInHopper[i].CoinLevel;
						}
						valFind = valFind - py->SplitQty[i] * py->CoinsInHopper[i].CoinValue;
				}				
			}
			if(valFind < 0)
				return 1;
			else
				return (UINT32)valFind;			
		}
	}else{
		/* if there is some value left to find, now start from the highest value and work down to the lowest */
		if(valFind){
			/* reset the values */
			if(py->DealMode == DEAL_MODE_SPLIT){
				for(i = 0 ; i < py->NumberOfCoinValues; i++)
					py->SplitQty[i] = 0;
					valFind = (INT32)valueToFind;	
			}
				
			for(i = py->NumberOfCoinValues - 1; i >= 0; i--){
				/* do we want to take note of the coin levels in the hopper  */
				if(py->LevelMode == LEVEL_CHECK_ON){
					if(py->CoinsInHopper[i].CoinLevel)
						 levelTest = 1;
					else
						levelTest = 0;
				}
				else
					levelTest = 1;				
				
			  curMatch = 1;  /* is this coin our country code */
			  for(j = 0; j < 3; j++){
			  	if(py->PayoutCountryReq[j] != py->CoinsInHopper[i].CountryCode[j])
			  		curMatch = 0;
			  } 		
								
				if(curMatch	&& (levelTest && (py->Mode == FLOAT_PAYOUT_TO_CASHBOX || py->FloatMode[i] == FLOAT_PAYOUT_TO_PAYOUT))){
					newQty = valFind/ py->CoinsInHopper[i].CoinValue;
					if(newQty){  /* if the division >= 1  */
							if(py->LevelMode == LEVEL_CHECK_ON){
							if(newQty <= py->CoinsInHopper[i].CoinLevel) /* if we have enough to cover this quantity  */
								py->SplitQty[i] += newQty;
							else{
								py->SplitQty[i] = py->CoinsInHopper[i].CoinLevel;  /* else make the quantity equal to the coins left  */
								newQty = py->CoinsInHopper[i].CoinLevel;
							}
						}else{
							py->SplitQty[i] += newQty;							
						}
							/* reduce the value to find  */
						valFind = valFind - (newQty* py->CoinsInHopper[i].CoinValue);	
					}
				}
			}
		}	
	}
		
	return (UINT32)valFind;
}



/*    DLL function call to generate host intermediate numbers to send to slave  */
NOMANGLE int CCONV InitiateSSPHostKeys(__int64*  keyArray ,SSP_COMMAND* cmd)
{
	int i;
	unsigned char portIndex;
	__int64 swap = 0;

	/* create the two random prime numbers  */
	keyArray[KEY_GENERATOR] = GeneratePrime();
	keyArray[KEY_MODULUS] = GeneratePrime();
	/* make sure Generator is larger than Modulus   */
	if (keyArray[KEY_GENERATOR] > keyArray[KEY_MODULUS])
	{
		swap = keyArray[KEY_GENERATOR];
		keyArray[KEY_GENERATOR] = keyArray[KEY_MODULUS];
		keyArray[KEY_MODULUS] = swap;
	}


	if(CreateHostInterKey(keyArray)== -1)
		return 0;


	/* find which port for multi system  */
	if(systemPorts.NumberOfPorts){ 
		portIndex = 255;
			/* find which poer index is for this cmd  */
		for(i = 0; i < MAX_PORT_ID; i++){
				if(systemPorts.PortID[i] == cmd->PortNumber){
					portIndex = i;
					break;
				}
		}
			/* valid port found ? */
		if(portIndex < 255){
			systemPorts.sspPkt[portIndex].encPktCount[cmd->SSPAddress] = 0;   		
		}
	}

	/* reset the apcket counter here for a successful key neg  */
	encPktCount[cmd->SSPAddress] = 0;

	return 1;
}





/* creates the host encryption key   */
NOMANGLE int CCONV CreateSSPHostEncryptionKey(__int64* keyArray)
{
	keyArray[KEY_HOST] = XpowYmodN(keyArray[KEY_SLAVE_INTER],keyArray[KEY_HOST_RANDOM],keyArray[KEY_MODULUS]);

	return 1;
}


 int EncryptSSPPacket(unsigned char ptNum,unsigned char* dataIn, unsigned char* dataOut, unsigned char* lengthIn,unsigned char* lengthOut, unsigned __int64* key)
{
	#define FIXED_PACKET_LENGTH   7
	unsigned char pkLength,i,packLength = 0;
	unsigned short crc;
	unsigned char tmpData[255];

	
	pkLength = *lengthIn + FIXED_PACKET_LENGTH;
    
	/* find the length of packing data required */
	if(pkLength % C_MAX_KEY_LENGTH != 0){
		packLength = C_MAX_KEY_LENGTH - (pkLength % C_MAX_KEY_LENGTH);
	}
	pkLength += packLength;

	tmpData[0] = *lengthIn; /* the length of the data without packing */

	/* add in the encrypted packet count   */
	for(i = 0; i < 4; i++)
		tmpData[1 + i] = (unsigned char)((encPktCount[ptNum] >> (8*i) & 0xFF));


	for(i = 0; i < *lengthIn; i++)
		tmpData[i + 5] = dataIn[i];

	/* seed random number gen */
	srand( (unsigned)time ( NULL ) );

	/* add random packing data  */
	for(i = 0; i < packLength; i++){
		tmpData[5 + *lengthIn + i] = (unsigned char)(rand() % 255);
	}
	/* add CRC to packet end   */
	
	crc = cal_crc_loop_CCITT_A(pkLength - 2,tmpData,CRC_SSP_SEED,CRC_SSP_POLY);
	
	tmpData[pkLength - 2] = (unsigned char)(crc & 0xFF);
	tmpData[pkLength - 1] = (unsigned char)((crc >> 8) & 0xFF);

	if (aes_encrypt( C_AES_MODE_ECB,(unsigned char*)key,C_MAX_KEY_LENGTH,NULL,0,tmpData,&dataOut[1],pkLength) != E_AES_SUCCESS)
							return 0;
	
	pkLength++; /* increment as the final length will have an STEX command added   */	
	*lengthOut = pkLength;
	dataOut[0] = SSP_STEX;

	encPktCount[ptNum]++;  /* incremnet the counter after a successful encrypted packet   */

	return 1;
}


 int EncryptSSPMultiplePortPacket(unsigned char portIndex, unsigned char address,unsigned char* dataIn, unsigned char* dataOut, unsigned char* lengthIn,unsigned char* lengthOut, unsigned __int64* key)
{
	#define FIXED_PACKET_LENGTH   7
	unsigned char pkLength,i,packLength = 0;
	unsigned short crc;
	unsigned char tmpData[255];

	
	pkLength = *lengthIn + FIXED_PACKET_LENGTH;
    
	/* find the length of packing data required */
	if(pkLength % C_MAX_KEY_LENGTH != 0){
		packLength = C_MAX_KEY_LENGTH - (pkLength % C_MAX_KEY_LENGTH);
	}
	pkLength += packLength;

	tmpData[0] = *lengthIn; /* the length of the data without packing */

	/* add in the encrypted packet count   */
	for(i = 0; i < 4; i++)
		tmpData[1 + i] = (unsigned char)((systemPorts.sspPkt[portIndex].encPktCount[address]  >> (8*i) & 0xFF));

	

	for(i = 0; i < *lengthIn; i++)
		tmpData[i + 5] = dataIn[i];

	/* seed random number gen */
	srand( (unsigned)time ( NULL ) );

	/* add random packing data  */
	for(i = 0; i < packLength; i++){
		tmpData[5 + *lengthIn + i] = (unsigned char)(rand() % 255);
	}
	/* add CRC to packet end   */
	
	crc = cal_crc_loop_CCITT_A(pkLength - 2,tmpData,CRC_SSP_SEED,CRC_SSP_POLY);
	
	tmpData[pkLength - 2] = (unsigned char)(crc & 0xFF);
	tmpData[pkLength - 1] = (unsigned char)((crc >> 8) & 0xFF);

	if (aes_encrypt( C_AES_MODE_ECB,(unsigned char*)key,C_MAX_KEY_LENGTH,NULL,0,tmpData,&dataOut[1],pkLength) != E_AES_SUCCESS)
							return 0;
	
	pkLength++; /* increment as the final length will have an STEX command added   */	
	*lengthOut = pkLength;
	dataOut[0] = SSP_STEX;

	systemPorts.sspPkt[portIndex].encPktCount[address]++;  /* incremnet the counter after a successful encrypted packet   */

	return 1;
}


 int  DecryptSSPPacket(unsigned char* dataIn, unsigned char* dataOut, unsigned char* lengthIn,unsigned char* lengthOut, unsigned __int64* key)
{


	if (aes_decrypt( C_AES_MODE_ECB,(unsigned char*)key,C_MAX_KEY_LENGTH,NULL,0,dataOut,dataIn,*lengthIn) != E_AES_SUCCESS)
							return 0;	

	

	return 1;
}





/* Creates a host intermediate key */
int CreateHostInterKey(__int64* keyArray)
{

	if (keyArray[KEY_GENERATOR] ==0 || keyArray[KEY_MODULUS] ==0 )
		return -1;

	keyArray[KEY_HOST_RANDOM]= (__int64) (GenerateRandomNumber() % MAX_RANDOM_INTEGER);
	keyArray[KEY_HOST_INTER] = XpowYmodN(keyArray[KEY_GENERATOR],keyArray[KEY_HOST_RANDOM],keyArray[KEY_MODULUS] );

	return 0;	
}




/* -----------------------------------------------------------------------------------------------------------------*/
/*    These function are not usually included in the host implimentation - they inlcuded here so the user can		*/
/*	  test the key functions in the host and system	and so the user can impliment them in the slave					*/
/* -----------------------------------------------------------------------------------------------------------------*/

/* DLL function call to test user implimentation - emulates slave functions, uses host data to generate HOST and SLAVE keys 
|  These keys should be the same for a successful key negotation                                            */
NOMANGLE int CCONV TestSSPSlaveKeys(__int64*  keyArray)
{

	
	if(CreateSlaveInterKey(keyArray) == -1)
		return 0;
		
	CreateSSPHostEncryptionKey(keyArray);
	CreateSlaveEncryptionKey(keyArray);

	if(keyArray[KEY_HOST] == keyArray[KEY_SLAVE])
		return 1;
	else
		return 0;
}


/* Creates a slave encryption key - test function only - this is usually only implimented in the slave */
int CreateSlaveEncryptionKey(__int64* keyArray)
{
	keyArray[KEY_SLAVE] = XpowYmodN(keyArray[KEY_HOST_INTER],keyArray[KEY_SLAVE_RANDOM],keyArray[KEY_MODULUS]);

	return 0;
}


/* creates a slave intermediate key - test function only - this is usually implimented only in the slave  */
int CreateSlaveInterKey(__int64* keyArray)
{
	if ( keyArray[KEY_GENERATOR] ==0 || keyArray[KEY_MODULUS] ==0 )
		return -1;

	keyArray[KEY_SLAVE_RANDOM] = (__int64) (GenerateRandomNumber() % MAX_RANDOM_INTEGER);
	keyArray[KEY_SLAVE_INTER] = XpowYmodN(keyArray[KEY_GENERATOR],keyArray[KEY_SLAVE_RANDOM],keyArray[KEY_MODULUS]);
	return 0;
}
