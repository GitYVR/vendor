﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace eSSP_example
{
    public class ChannelData
    {
        public int Value;
        public byte Channel;
        public char[] Currency;
        public int Level;
        public bool Recycling;
        public ChannelData()
        {
            Value = 0;
            Channel = 0;
            Currency = new char[3];
            Level = 0;
            Recycling = false;
        }
    };

    public class CHelpers
    {
        // Helper function to convert 4 bytes to an int 32 from a specified array and index.
        static public int ConvertBytesToInt32(byte[] b, int index)
        {
            return BitConverter.ToInt32(b, index);
        }

        // 2 bytes to int 16
        static public int ConvertBytesToInt16(byte[] b, int index)
        {
            return BitConverter.ToInt16(b, index);
        }

        // Convert int32 to byte array
        static public byte[] ConvertIntToBytes(int n)
        {
            return BitConverter.GetBytes(n);
        }

        // Convert int16 to byte array
        static public byte[] ConvertIntToBytes(short n)
        {
            return BitConverter.GetBytes(n);
        }

        // Convert int8 to byte
        static public byte[] ConvertIntToBytes(char n)
        {
            return BitConverter.GetBytes(n);
        }

        // Helper uses value of channel and adds a decimal point and two zeroes, also adds current
        // currency.
        static public string FormatToCurrency(int unformattedNumber)
        {
            float f = unformattedNumber * 0.01f;
            return f.ToString ("0.00");
        }

       
    }
    
}
