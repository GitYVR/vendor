﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSSP_example
{
    public class Global
    {
        public static string ComPort = "";
        public static byte Validator1SSPAddress = 0;
        public static byte Validator2SSPAddress = 0;
    }
}
